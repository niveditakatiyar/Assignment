package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ques4 {

	public static void main(String[] args){
			System.setProperty("webdriver.chrome.driver","/home/nivedita/Documents/Testing_Java/Chromedriver/chromedriver");
			WebDriver driver=new ChromeDriver();
			driver.get("http://www.tothenew.com/");
			driver.findElement(By.xpath("(//*[@id=\'h-contact-us\'])[2]")).click(); //Xpath
			
	}

}
