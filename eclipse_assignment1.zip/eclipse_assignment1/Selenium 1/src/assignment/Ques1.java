package assignment;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Ques1 {

	public static void main(String[] args) {
		System.setProperty("webdriver.gecko.driver","/home/nivedita/Documents/Testing_Java/Geckodriver/geckodriver");
		WebDriver driver=new FirefoxDriver();
		driver.get("https://www.google.com/");
	}

}
