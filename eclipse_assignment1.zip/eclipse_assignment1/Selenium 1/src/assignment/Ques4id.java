package assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Ques4id {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","/home/nivedita/Documents/Testing_Java/Chromedriver/chromedriver");
		WebDriver driver=new ChromeDriver();
		driver.get("http://www.tothenew.com/");
		JavascriptExecutor js = ((JavascriptExecutor) driver);
		js.executeScript("window.scrollTo(0,2000)");
		Thread.sleep(1000);
		driver.findElement(By.id("h-contact-us")).click();

	}

}
